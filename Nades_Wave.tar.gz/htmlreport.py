#!/usr/bin/python3.5
###############################################################################
#
#   Author:   Nades Nadarajah
#   Function: This module handle the output data.
#             It converts the input mattrix file and format to as html file.

#   Date:     March 31, 2018
#
################################################################################

import os
import sys
from sys import stdin
import html
import json
from mydate import *

csv_report_file = os.environ['CSV_REPORT_FILE']
json_file = os.environ['CSV_MATTRIX_FILE']


if csv_report_file == "":
    csv_report_file = "sample.csv.html"
if json_file == "":
    json_file = "sample.csv.json"

# Load the json object from the payment class.
# This is the object contains all calculated payment information.
# The file is in json dump of the object.
mattrix = []
iFile = open(json_file, "r")
mattrix = json.load(iFile)
iFile.close()

#Header for table
header = """<table cellpadding="4" cellspacing="0" style="border: 1px solid #000000; padding: 0.1cm">
	<col width="10*">
	<col width="250*">
	<col width="85*">"""
border = '<td width="33%" style="border: 1px solid #000000; padding: 0.1cm">'

def htmlformat(id, period, pay):
    return '{}{}</td>{}{}</td>{}{}</td>'.format(border,id,border,period,border,pay)


################################################################
# Write the data in html format
################################################################
oFile = open (csv_report_file, "w")
oFile.write(header)

#add column headings
template_line = '<tr> %s</tr>'
row = htmlformat("Employee ID", "Pay Period", "Amount Paid")
oFile.write(template_line % (row))

for row in mattrix:
    id, rDate, fPay = row.split(",")
    r = range(rDate)
    repDate = r.revFormat()
    row = htmlformat(id, repDate, fPay)
    oFile.write(template_line %(row))

oFile.write("</table>")
oFile.close()
