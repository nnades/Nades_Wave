#!/usr/bin/python3.5

###############################################################################
#
#   Author:   Nades Nadarajah
#   Function: This is mydate package provides date calculation.
#
#   Date:     March 31, 2018
#
################################################################################

import os
import sys
from sys import stdin
from datetime import date

# Pay start and end dates for the first period
# The second pay period starts from the next day, to the end of the month.
# We assume it is always 31st.
pay_start_end = [1,15]
lastpay_start = [16, 31]
days_in_month = [0,31,28,31,30,31,30,31,31,30,31,30,31]

# The class range has three attributes:
# dStart - Start date of the pay period (based on the entered date).
# dEnd   - End date of the pay period (based on the entered date).
# firstPay - will have value 1 for the first pay period, 0 for the second.
class range:
    dStart = date(2000,1,1)
    dEnd = date(2000,1,1)
    firstPay = 1

    def __init__(self, start, end="1/1/1", firstPay=1):
        if end == "1/1/1":
            self.dStart, self.dEnd = start.split(":")
        else:
            self.dStart = start
            self.dEnd = end
            self.firstPay = firstPay

    def __str__(self):
        return "Start=%s, End=%s - isFirstPay=%d" %(self.dStart, self.dEnd, self.firstPay)

    def revFormat(self):
        i1, i2, i3 = self.dStart.split("-")
        d1 = "%s/%s/%s" %(i3, i2, i1)
        i1, i2, i3 = self.dEnd.split("-")
        d2 = "%s/%s/%s" %(i3, i2, i1)
        return "%s - %s" %(d1,d2)

# This class only compares the passed date and returns the actual pay
# period based on the given date.
class dateRange:

    @classmethod
    def getPayPeriod(cls, sDate):
        if sDate == "":
            return 1

        #check the pay start and end period
        aDate = sDate.split("/")
        iDD, iMM, iYY = aDate

        if int(iDD) < int(pay_start_end[1]) + 1:
            firstPay = 1
            start = date(int(iYY),int(iMM),int(pay_start_end[0]))
            end = date(int(iYY),int(iMM),int(pay_start_end[1]))
        else:
            firstPay = 0
            start = date(int(iYY),int(iMM),int(lastpay_start[0]))
            end = date(int(iYY),int(iMM),int(days_in_month[int(iMM)]))

        r1 = range(start, end, firstPay)
        #print (str(r1))
        return r1

