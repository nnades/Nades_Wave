#!/usr/bin/python3.5

###############################################################################
#
#   Author:   Nades Nadarajah
#   Function: This is mydate package provides date calculation.
#
#   Date:     March 28, 2018
#
################################################################################

import os
import sys
from sys import stdin
import time
from datetime import date

# Pay start and end dates for the first period
# The second pay period starts from the next day to the end of the month.
pay_start_end = [1,15]


# The class range has three attributes:
# dStart - Start date of the pay period (based on the entered date).
# dEnd   - End date of the pay period (based on the entered date).
# firstPay - will have value 1 for the first pay period, 0 for the second.
class range:
    dStart = ""
    dEnd = ""
    firstPay = 1
    def __init__(self, *arg):
        self.dStart = arg[0]
        self.dEnd = arg[1]
        self.firstPay = arg[2]

    def __str__(self):
        return "Start=%s, End=%s - isFirstPay=%d" %(self.dStart, self.dEnd, self.firstPay)

# This class only compares the passed date and returns the actual pay
# period based on the given date.
class dateRange:

    @classmethod
    def getPayPeriod(cls, sDate):
        if sDate == "":
            return 1

        #check the pay start and end period
        aDate = sDate.split("/")
        iDD, iMM, iYY = aDate

        if int(iDD) < int(pay_start_end[1]) + 1:
            firstPay = 1
            start = "%s/%s/%s" %(pay_start_end[0],iMM, iYY)
            end = "%s/%s/%s" %(pay_start_end[1],iMM, iYY)
        else:
            firstPay = 0
            start = "%s/%s/%s" %(pay_start_end[1]+1,iMM, iYY)
            #Need to calculate actual end date of the month
            end = "%s/%s/%s" %(31,iMM, iYY)

        r1 = range(start, end, firstPay)
        #print (str(r1))
        return r1
