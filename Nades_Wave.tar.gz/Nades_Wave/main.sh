#!/bin/bash
###############################################################################
#
#   Author:   Nades Nadarajah
#   Function: This is the main function.
#   Date:     March 28, 2018
#   Copyright:
################################################################################

SCRIPT_DIR=`pwd`

echo $SCRIPT_DIR

if [[ $# == 0 ]]
then
    echo "ERROR: Missing filename..."
    echo "e.g. ./main.sh sample.csv"
    exit 1
fi

file_name=$1

export CSV_DATA_FILE=$file_name
export CSV_MATTRIX_FILE="$file_name.json"
export CSV_REPORT_FILE="$file_name.html"
export PAST_REPORT_IDS="past_reports.txt"

echo "CSV_DATA_FILE=$CSV_DATA_FILE"
echo "CSV_MATTRIX_FILE=$CSV_MATTRIX_FILE"
echo "CSV_REPORT_FILE=$CSV_REPORT_FILE"

#Call payment.py script to process the data

#verify if the report file is already processed
report_id=`grep "report id" $CSV_DATA_FILE | awk -F "," '{printf $2}'`
echo "Current report id = $report_id"

#check if it is in the past reports file.
past_id=`grep $report_id $PAST_REPORT_IDS | awk '{printf $1}'`
if [[ ${past_id} != "" ]]
then
    echo "ERROR:The report is processed already in the past."
    exit 1
fi

#Append to past reports file
echo "Appending $report_id to the file=$PAST_REPORT_IDS"
echo $report_id >> $PAST_REPORT_IDS

echo "Start processing..."
./payment.py
echo "Done payment.py..."

./htmlreport.py
echo "Done " + $CSV_REPORT_FILE + " report file..."
firefox $CSV_REPORT_FILE