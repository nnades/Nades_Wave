#!/usr/bin/python3.5

###############################################################################
#
#   Author:   Nades Nadarajah
#   Function: This function allows the user to input a time report file.
#             Reads the report id and the unique identifier from the file.
#             If the report file is a new file to be processed then pass it to
#             the input module.
#   Date:     March 28, 2018
#
################################################################################

import os
import sys
from sys import stdin
import time
from datetime import date
import datetime
import pickle
import json

from mydate import *

csvFile = ""

#The following dictonary defines the pay groups
groups = {"A": 20, "B": 30}

# Local variable holds the payments for the current pay period
# Key=(id, start), Value= amount
#payMattrix[(1, "2018/01/14")] = 300
payMattrix = {}
num_lines_in_report = 0

#Calculate the pay for the hours worked using group
def calculate(fHours=0, aGrp = "A"):

    try:
        fPay = groups[aGrp]
    except KeyError:
        print ("ERROR: %s KeyError in groups[] Key=%s" %(__file__, aGrp))
        exit(1)

    tmp = 0
    if fHours != 0 or fPay == "":
        tmp = float(float(fHours)*fPay)
    return tmp

#define class payment
class PaymentClass:
    report_id = 0

    def __init__(cls, filename):
        if filename == "":
            print ("ERROR: %s Filename=%s error. " %(__file__, filename))

        iFile = ''
        try:
            iFile = open(filename, "r")
            lines = iFile.readlines()
        finally:
            iFile.close()

        #goto the last line
        num_lines_in_report = len(lines)
        last_line = lines[num_lines_in_report-1]
        report_id = last_line.split(",")[1]

        # progress each line from the file
        for line in lines:
            addToPayMattrix(line)

    def writeMattrix(cls, filename):
        iFile = open(filename, "w")

        #sort the items in the mattrix
        keys = list(payMattrix.keys())
        keys.sort()
        #(4, '16/12/2016', '31/12/2016')
        template = '%i, %s - %s, %.2f\n'
        for iKey in keys:
            fPay = payMattrix[iKey]
            data = template % (int(iKey[0]), iKey[1], iKey[2], float(fPay))
            iFile.write("%s"%(data))
        iFile.close()

    def writeMattrix1(cls, filename):

        mattrix = {}

        #sort the items in the mattrix
        keys = list(payMattrix.keys())
        keys.sort(key=str)
        #Key = (4, '16/12/2016', '31/12/2016')
        #Value = nnn
        template = '%i, %s - %s'
        for ikey in keys:
            fPay = payMattrix[ikey]
            aList = list(ikey)
            aID, dStart, dEnd = aList
            data = template % (int(aID), dStart, dEnd)
            mattrix[data] = float(fPay)

        tmpFile = filename + ".pk"
        oFile = open(tmpFile, "wb")
        pickle._dump(mattrix,oFile)
        oFile.close()

        oFile = open(filename, "w")
        json.dump(mattrix, oFile, indent=3)
        oFile.close()


# This function is called to calculate the pay for the given entry in the timesheet
# The result is added to the payMattrix[]
#date,hours worked,employee id,job group
#14/11/2016,7.5,1,A
def addToPayMattrix(line):
    fPastpay = 0.0

    #skip the first and the last line
    if "date,hours" in line or "report id" in line:
        print ("Ignore this line: %s" %(line))
        return 0

    line = line.strip()
    aLine = line.split(",")

    #read each value -> 14/11/2016,7.5,1,A
    if len(aLine) == 4:
        dd, hours, id, grp = aLine
    else:
        print ("ERROR: %s invalid data %s" %(__file__, aLine))

    fPay = calculate(hours, grp)
    period = dateRange.getPayPeriod(dd)

    # payMattrix[(1, "2018/01/14")] = 300
    try:
        fPastpay = payMattrix[id, period.dStart, period.dEnd]
    except:
        print("New key value: %s %s - %s "%(id, period.dStart, period.dEnd))

    payMattrix[id, period.dStart, period.dEnd] = float(fPastpay) + float(fPay)

    return 0


#Python main entry
csvFile = os.environ['CSV_DATA_FILE']
if csvFile == "":
    csvFile = "sample.csv"

jsonFile = "%s.json"%(csvFile)
PaymentClass(csvFile)
PaymentClass.writeMattrix1(PaymentClass, jsonFile)
